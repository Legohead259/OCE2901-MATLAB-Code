% Calculates several wave characteristics based on passed surface displacement data (eta).
% NOTE: This data should be as santized and clean as possible before being
% passed to this function. It will not do any sanitization beforehand
% This function works by breaking the wave data into distinct waves via the
% zero upcrossing method. THis method delimits waves by where the data
% transitions from a negative value to a positive value.

% @param data: the *sanitized* eta function to be processed in specified units
% @param freq: the sampling frequency of the data in Hertz (Defaults to 1)
% @return delims: an array of indexes where the eta data is delimitted to individual waves
% @return H_avg: the average wave height from the data in units
% @return H_highthird: an array of the highest 1/3 of wave heights in units
% @return H_rms: the RMS of the wave height data in units
% @return T_avg: the average period from the data in seconds
% @return T_highthird: the period of the heighest 1/3 of waves in seconds
function [delims, H_avg, H_highthird, H_rms, T_avg, T_highthird] = wave_by_wave(data, freq)
    arguments
        data;
        freq = 1;
    end
    
    % Determine wave deliminations via to upcross method (data goes from neg to positive)
    delims = upcross(data);

    % Create an array of wave structs to work with
    for i=1:length(delims)-1
        waves(i).values = data(delims(i):delims(i+1));                  % Determine data for specific wave between delimitters
        waves(i).height = max(waves(i).values) - min(waves(i).values);  % Determine wave height as the trough+crest
        waves(i).period = (delims(i+1) - delims(i)) / freq;             % Determine the wave period by distance between up-crossings
    end
        
    % Calculate height data
    Heights = [waves(1:end).height];                            % Create array of heights from struct array
    H_avg = mean(Heights);                                      % Find average wave heights
    [Heights, Idx] = sort(Heights, "descend");                  % Sort wave heights from largest-smallest
    H_highthird = mean(Heights(1:fix(numel(Heights)/2)));       % Determine average of top 1/3 of wave heights
    H_rms = rms(Heights);                                       % Find RMS of wave heights

    % Calculate period data
    T_avg = mean([waves(1:end).period]);                            % Determine average period from the struct array
    T_highthird = mean([waves(Idx(1:fix(numel(Idx)/3))).period]);   % Determine the average period of the high 1/3 of waves
end