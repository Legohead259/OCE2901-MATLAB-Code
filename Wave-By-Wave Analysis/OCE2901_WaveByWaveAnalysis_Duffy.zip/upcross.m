% Identifies the locations (indicies) of where the continuous free surface
% displacement function (eta) crosses 0 from negative to positive. This is
% one method to identify individual waves within the eta function.
% @param eta: the continuous free surface diplacement function
% @return upcross_locs: the indicies within eta where the function crosses 0 from negative to positive
function upcross_locs = upcross(eta)
    index = 1; % instantiate upcrosses index
    
    neg_data_locs = find(eta < 0); % Generate index array of negative data values
    for i=1:length(neg_data_locs)
        try
            if eta(neg_data_locs(i)+1) >= 0 % Identify locations of up-crossings
%                 disp("Found an upcross!") % DEBUG
                upcross_locs(index) = neg_data_locs(i);
                index = index + 1;
            end
        catch
            continue
        end
    end
end