% Loads in the CSV file produced by a HOBO pressure gauge and manipulates
% it. The manipulations yield a continuous pressure function and a
% continuous free surface displacment function, eta
% @param fn: the filename for the CSV file to be loaded
% @param p_start: the starting index for the good pressure data (Defaults to 1)
% @param p_end: the ending index for the good pressure data (Defaults to 1)
% @param atmo_end: the index where the atmospheric pressure data ends (Defaults to 100)
% @return pressure_data: a continuous pressure function from the raw data in kPa
% @return eta_data: a continuous free surface displacement function (eta) in meters
% @return atmo_pressure: the atmospheric pressure during recording in kPa
function [pressure_data, eta_data, atmo_pressure] = load_HOBO_csv(fn, p_start, p_end, atmo_end)
    arguments
        fn string
        p_start (1,1) {mustBeNumeric} = 1
        p_end (1,1) {mustBeNumeric} = 1
        atmo_end (1,1) {mustBeNumeric} = 100
    end
    extraneous_vars = ["Var1", "Var2", "Var5", "Var6", "Var7", "Var8", "Var8", "Var9"];
    
    data_table = readtable(fn, "HeaderLines", 2);                   % Load the HOBO data and ignore the two header rows
    data_table = removevars(data_table, extraneous_vars);           % remove the extraneous variable columns from the data
    pressure_array = table2array(data_table);                       % Convert the HOBO data table into a Nx2 matrix
    atmo_pressure = mean(pressure_array(1:atmo_end));               % Determine atmospheric pressure
    pressure_data = pressure_array(p_start:p_end) - atmo_pressure;  % Trim pressure data and convert to gauge pressure
    eta_data = pressure2eta(pressure_data);                         % Convert pressure data to eta function
end